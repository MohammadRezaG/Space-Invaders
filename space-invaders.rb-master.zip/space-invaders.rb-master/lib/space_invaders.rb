require 'gosu'

module SpaceInvaders
end