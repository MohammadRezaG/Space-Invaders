require 'pry'
require './lib/space_invaders'
require './lib/space_invaders/app'

SpaceInvaders::App.new.show
